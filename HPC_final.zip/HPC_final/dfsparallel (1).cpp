#include <iostream>
#include <vector>
#include <omp.h>

using namespace std;

const int MAXN = 1e5;
vector<int> adj[MAXN]; // adjacency list

bool visited[MAXN]; // mark visited nodes

void dfs(int node) 
{
	
	visited[node] = true;
	cout<<node<<" ";
      
	#pragma omp parallel for
	for (int i = 0; i < adj[node].size(); i++) 
	{
		int next_node = adj[node][i];
		 	if (!visited[next_node]) 
			{
		 		dfs(next_node);
		 	}
 	}
}
int main() 
{
 int n, m; // number of nodes and edges
 
 cout<<"Enter number of nodes and edges: ";
 cin >> n >> m;
 for (int i = 1; i <= m; i++) {
 int u, v; // edge between u and v
 cin >> u >> v;
 adj[u].push_back(v);
 adj[v].push_back(u);
 }
 int start_node; // start node of DFS
 cout<<"Enter Start node: ";
 cin >> start_node;

 double start = 0.0, end = 0.0;
start = omp_get_wtime();
 dfs(start_node);
 
/*
cout<<"DFS Traversal: "<<endl;
 
// Print visited nodes
 for (int i = 1; i <= n; i++) 
 {
 	if (visited[i]) 
	{
 		cout << i << " ";
 	}
 }
 */
 
 end = omp_get_wtime();
 cout<<"\nComputation time: "<<end - start<<endl;
 cout << endl;
 return 0;
}

