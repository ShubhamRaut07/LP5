/* #include <iostream>
#include <vector>
#include <algorithm> */
#include <omp.h>
#include<bits/stdc++.h>

using namespace std;
void bubbleSort(vector<int>& arr){
    int n = arr.size();
    
    for(int i=0; i<n-1; i++){
        
        for(int j=0; j<n-i-1; j++){
            if(arr[j]>=arr[j+1]){
                swap(arr[j], arr[j+1]);
            }
        }
    }
}

int main(){
    vector<int> arr;
    
    for(int i = 0; i < 10; i++) 
	{
        int n;
        cin >> n;
        arr.push_back(n);
    }
    
    cout << "original :" << endl;
    for(int num : arr){
        cout << num << " ";
    }
   cout << endl;
    
    double start = omp_get_wtime();
    
    bubbleSort(arr);
    
    double end = omp_get_wtime();
    double Time = (end - start) * 1000.0;
    
   cout << "sorted :" << endl;
    for(int num : arr)
	{
       cout << num << " ";
    }
   cout <<endl;
    
   cout << "time taken :" << Time << " milliseconds";
    
    return 0;
}
