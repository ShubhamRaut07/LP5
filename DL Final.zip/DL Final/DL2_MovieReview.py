#!/usr/bin/env python
# coding: utf-8

# # **Movie Review**

# In[1]:


get_ipython().system('pip install tensorflow')


# In[5]:


get_ipython().system('pip install tensorflow-text')


# In[6]:


import pandas as pd
import tensorflow
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Embedding, LSTM, Dense


# In[ ]:


# Load the dataset
data = pd.read_csv('C:\\Users\\shree\\Downloads\\LP5-20230529T145226Z-001\\LP5\\Datasets\\IMDB Dataset.csv')


# In[ ]:


# Split the data into training and testing sets
train_data, test_data = train_test_split(data, test_size=0.2, random_state=42)


# In[ ]:


# Preprocess the data
tokenizer = Tokenizer(num_words=10000)
tokenizer.fit_on_texts(train_data['review'])


# In[ ]:


print(train_data['review'][:5])
X_train = tokenizer.texts_to_sequences(train_data['review'])
X_test = tokenizer.texts_to_sequences(test_data['review'])
print(X_train[:5])


# In[ ]:


max_len = max([len(x) for x in X_train])
X_train = pad_sequences(X_train, maxlen=max_len)
X_test = pad_sequences(X_test, maxlen=max_len)


# In[ ]:


print(train_data['sentiment'][:5])
label_encoder = LabelEncoder()
y_train = label_encoder.fit_transform(train_data['sentiment'])
y_test = label_encoder.transform(test_data['sentiment'])
print(y_train[:5])


# In[ ]:


# Build the model
model = Sequential()
model.add(Embedding(10000, 128, input_length=max_len))
model.add(LSTM(128))
model.add(Dense(1, activation='sigmoid'))


# In[ ]:


model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])


# In[ ]:


# Train the model
model.fit(X_train, y_train, batch_size=16, epochs=10, validation_data=(X_test, y_test))


# In[ ]:


# Evaluate the model
loss, accuracy = model.evaluate(X_test, y_test)
print(f'Test loss: {loss:.5f}')
print(f'Test accuracy: {accuracy:.5f}')


# In[ ]:


predictions = model.predict(X_test[:5])


# In[ ]:


print(predictions)
print(y_test[:5])


# In[ ]:




