#!/usr/bin/env python
# coding: utf-8

# In[65]:


import pandas as pd
import numpy as np


# In[75]:


from sklearn.datasets import load_boston
boston = load_boston()


# In[76]:


data = pd.DataFrame(boston.data)
data.head()
data.shape


# In[77]:


data.columns = boston.feature_names
data.head()


# In[78]:


data['PRICE'] = boston.target


# In[79]:


data.head()


# In[80]:


data.shape


# In[93]:


from sklearn.linear_model import LinearRegression


# In[94]:


lm = LinearRegression()


# In[ ]:





# In[98]:


data['PRICE'] = boston.target

X = data.drop(['PRICE'], axis = 1)
y = data['PRICE']
data.head()


# In[99]:


from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X,y, test_size = 0.3, random_state=42)


# In[100]:


lm.fit(X_train, y_train)


# In[101]:


lm.intercept_


# In[102]:


#Converting the coefficient values to a dataframe
coeffcients = pd.DataFrame([X_train.columns,lm.coef_]).T
coeffcients = coeffcients.rename(columns={0: 'Attribute', 1: 'Coefficients'})
coeffcients


# In[105]:


#model prediction using linear regression

# Model prediction on train data
y_pred = lm.predict(X_train)


# In[108]:


#accuracy and error
from sklearn import metrics
print('R^2:',metrics.r2_score(y_train, y_pred))
print('MSE:',metrics.mean_squared_error(y_train, y_pred))


# In[90]:


from sklearn.preprocessing import StandardScaler
sc = StandardScaler()
X_train = sc.fit_transform(X_train)
X_test = sc.transform(X_test)


# In[87]:


import keras
from keras.layers import Dense, Activation
from keras.models import Sequential
model = Sequential()
model.add(Dense(16,activation = 'relu',input_dim = 14))
model.add(Dense(32,activation = 'relu'))
model.add(Dense(64,activation = 'relu'))
model.add(Dense(128,activation = 'relu'))
model.add(Dense(1))
model.compile(optimizer = 'adam',loss = 'mean_squared_error')
model.summary()
model.fit(X_train, y_train, epochs = 100)


# In[91]:


y_pred = model.predict(X_test)

from sklearn.metrics import r2_score
r2 = r2_score(y_test, y_pred)
print("Accuracy :",r2)


# In[92]:


from sklearn.metrics import mean_squared_error
rmse = (np.sqrt(mean_squared_error(y_test, y_pred)))
print(rmse)


# In[ ]:




