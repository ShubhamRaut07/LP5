#!/usr/bin/env python
# coding: utf-8

# In[110]:


get_ipython().system('pip install --upgrade tensorflow')

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from keras.layers import LSTM, Dropout, Dense
from tensorflow.keras.models import Sequential


# In[112]:


dataset_train = pd.read_csv('C:\\Users\\shree\\Downloads\\Deep Learning\\Deep Learning\\Google_Stock_Price_Train.csv')


# In[113]:


training_set = dataset_train.iloc[:, 1: 2].values


# In[114]:


from sklearn.preprocessing import MinMaxScaler
sc = MinMaxScaler(feature_range = (0, 1))
training_set_scaled = sc.fit_transform(training_set)


# In[115]:


X_train = []
y_train = []
for i in range(60, len(training_set_scaled)):
    X_train.append(training_set_scaled[i-60: i, 0])
    y_train.append(training_set_scaled[i, 0])


# In[116]:


X_train, y_train = np.array(X_train), np.array(y_train)


# In[117]:


X_train = np.reshape(X_train, newshape = (X_train.shape[0], X_train.shape[1], 1))


# In[118]:


regressor = Sequential()


# In[119]:


# Add the 1st LSTM layer with the Dropout layer followed.

regressor.add(LSTM(units = 50, return_sequences = True, input_shape = (X_train.shape[1], 1)))
regressor.add(Dropout(rate = 0.2))


# In[120]:


## Add 2nd lstm layer
regressor.add(LSTM(units = 50, return_sequences = True))
regressor.add(Dropout(rate = 0.2))


# In[121]:


## Add 3rd lstm layer
regressor.add(LSTM(units = 50, return_sequences = True))
regressor.add(Dropout(rate = 0.2))


# In[122]:


## Add 4th lstm layer
regressor.add(LSTM(units = 50, return_sequences = False))
regressor.add(Dropout(rate = 0.2))


# In[123]:


regressor.add(Dense(units = 1))


# In[124]:


regressor.compile(optimizer = 'adam', loss = 'mean_squared_error')


# In[126]:


regressor.fit(x = X_train, y = y_train, batch_size = 32, epochs = 10)


# In[127]:


dataset_test = pd.read_csv('C:\\Users\\shree\\Downloads\\Deep Learning\\Deep Learning\\Google_Stock_Price_Test.csv')
real_stock_price = dataset_test.iloc[:, 1: 2].values


# In[128]:


# Data processing

dataset_total = pd.concat((dataset_train['Open'],dataset_test['Open']), axis = 0)

inputs = dataset_total[len(dataset_total)-len(dataset_test)- 60: ].values


# In[129]:


inputs = inputs.reshape(-1, 1)

inputs = sc.transform(inputs)


# In[130]:


X_test = []
for i in range(60, len(inputs)): 
    X_test.append(inputs[i-60: i, 0])


# In[131]:


X_test = np.array(X_test)
# Make numpy array as 3D , adding num of indicator
X_test = np.reshape(X_test, newshape = (X_test.shape[0],  
                    X_test.shape[1], 1))


# In[132]:


predicted_stock_price = regressor.predict(X_test)

predicted_stock_price = sc.inverse_transform(predicted_stock_price)


# In[133]:


plt.plot(real_stock_price, color = 'red', label = 'Real price')
plt.plot(predicted_stock_price, color = 'blue', label = 'Predicted price')
plt.title('Google price prediction')
plt.xlabel('Time')
plt.ylabel('Price')
plt.legend()
plt.show()


# In[ ]:




